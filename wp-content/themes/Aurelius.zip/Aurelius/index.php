<?php get_header(); ?>
<div class="views">
    <div class="view view-main" data-page="welfare">
        <div class="pages navbar-fixed">
            <div data-page="welfare" class="page with-subnavbar">
                <div class="navbar">
                    <div class="navbar-inner">
                        <div class="subnavbar">
                            <div class="buttons-row">
                                <a href="#gift" class="tab-link active" onclick="return false">苹果赚钱</a>
                                <a href="#news" class="tab-link" onclick="return false;">安卓赚钱</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tabs-swipeable-wrap swiper-container swiper-container-horizontal">
                    <div class="tabs swiper-wrapper">
                        <div id="gift" class="page-content tab swiper-slide swiper-slide-active active" style="width: 320px;">
                            <div class="content-block">
                                <div class="wrapper wrapper-gift-list" id="wrapper">
                                    <div class="ui-tab">
                                        <section class="list-block rank-list">
                                            <ul id="tab-content1" class="ui-list">
                                                <?php
                                                if (have_posts()):
                                                    while (have_posts()):
                                                        the_post();
                                                        get_template_part('template-parts/content', get_post_format());
                                                    endwhile;
                                                else:
                                                       // get_template_part('template-parts/content', 'none');
                                                endif;
                                                ?>
                                            </ul>
                                        </section>
                                    </div>
                                    <!-- 加载提示符 -->
                                    <div class="infinite-scroll-preloader infinite-scroll-preloader-margin hide" style="display: none;">
                                        <div class="preloader"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="news" class="page-content tab swiper-slide swiper-slide-next" style="width: 320px;">
                            <div class="content-block">
                                <div class="wrapper wrapper-activity-list" id="wrapper">
                                    <div class="ui-tab">
                                        <section class="list-block rank-list">
                                            <ul id="tab-content2" class="ui-list"></ul>
                                        </section>
                                    </div>
                                    <!-- 加载提示符 -->
                                    <div class="infinite-scroll-preloader infinite-scroll-preloader-margin hide">
                                        <div class="preloader"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
