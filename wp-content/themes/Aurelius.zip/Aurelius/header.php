<html class="pixel-ratio-2 retina ios ios-9 ios-9-1 ios-gt-8 ios-gt-7 ios-gt-6 watch-active-state"><head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="format-detection" content="telephone=no">
    <meta name="wap-font-scale" content="no">
    <meta name="keywords" content="">
    <meta name="description" content="X游网礼包中心免费提供最新最全手机网页游戏礼包、特权礼包、激活码、新手礼包、兑换码等游戏福利。">
    <meta name="360-site-verification" content="595918ad8c29e296bdc65ab6fb2d1195">
    <title>手机网页游戏礼包领取中心_激活码领取中心_礼包兑换码 - X游网</title>
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
</head>
<body class="framework7-root">
        <?php wp_head(); ?>