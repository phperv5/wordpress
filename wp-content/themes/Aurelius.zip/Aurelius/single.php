<?php get_header(); ?>
<?php if (have_posts()) : the_post();update_post_caches($posts); ?>
    <div class="views">
        <div class="view view-main" data-page="gift-detail">
            <div class="navbar">
                <div class="navbar-inner navbar-on-center header">
                    <div class="left sliding">
                        <a href="javascript:history.back();" class="back link">
                            <i class="icon icon-back"></i>
                            <span>&nbsp;</span>
                        </a>
                    </div>
                    <div class="center sliding" style="left: -12px;">苹果赚钱</div>
                    <div class="right share"></div>
                </div>
            </div>
            <div class="pages navbar-through">
                <div data-page="gift-detail" class="page page-on-center">
                    <div class="page-content">
                        <div class="wrapper wrapper-gift-detail-list wrapper-detail-index ui-list" id="wrapper">
                            <!-- 礼包详情 -->
                            <div class="list-block gift-detail-list ui-panel">

                                <div class="content-block-inner mod-gift">
                                    <h2 class="ui-arrowlink ui-border-b">首页>苹果</h2>
                                    <div class="mod-gift-info">
                                        <p class="ui-nowrap"><?php echo the_content(); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else : ?>
    <div class="errorbox">
        没有！
    </div>
<?php endif; ?>
<?php get_footer(); ?>