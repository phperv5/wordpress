
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/framework7.min.js?ver=3.1.2"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/xyou-plugins.min.js?ver=3.1.2"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/function.min.js?ver=3.1.2"></script>
<!-- <script type="text/javascript" src="http://www.xyou.cn/App/home/Assets/dist/Js/page/gift.min.js?ver=3.1.2"></script> -->
</body></html>